./compile.sh
./start.sh
