#!/bin/bash
./compile.sh
exec server/main
