#!/bin/bash
exec mvn package
