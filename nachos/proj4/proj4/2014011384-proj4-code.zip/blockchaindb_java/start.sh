#!/bin/sh
exec java -jar target/blockdb-1.0-SNAPSHOT.jar $@
