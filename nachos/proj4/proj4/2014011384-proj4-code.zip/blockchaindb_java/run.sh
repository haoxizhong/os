./compile.sh
./start.sh
